Blockly.Msg.YOLOBIT_BLE_START_TOOLTIP = 'start bluetooth with given name';
Blockly.Msg.YOLOBIT_BLE_START_MESSAGE0 = 'start bluetooth with name %1';
Blockly.Msg.YOLOBIT_BLE_START_HELPURL = '';
Blockly.Msg.YOLOBIT_BLE_ON_RECEIVE_MESSAGE_TOOLTIP = 'Define what to do when receive a bluetooth message from app';
Blockly.Msg.YOLOBIT_BLE_ON_RECEIVE_MESSAGE_MESSAGE0 = 'when receive %1 from app %2 %3';
Blockly.Msg.YOLOBIT_BLE_ON_RECEIVE_MESSAGE_MESSAGE1 = 'message';
Blockly.Msg.YOLOBIT_BLE_ON_RECEIVE_MESSAGE_HELPURL = '';
