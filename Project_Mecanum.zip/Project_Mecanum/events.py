import time
import tkinter.messagebox
from keras.models import load_model
import webbrowser
import cv2
import numpy as np
import globals


# buttons events - CONNECTIVITY
def buttonEvent__CLICK():
    tkinter.messagebox.showinfo(title="Error", message="Tính năng chưa được hỗ trợ")


def buttonEvent__CONNECTIVITY_APP_OHSTEM_HOMEPAGE():
    webbrowser.open_new(r"https://app.ohstem.vn/")


def buttonEvent__CONNECTIVITY_ADAFRUIT_HOMEPAGE():
    webbrowser.open_new(r"https://io.adafruit.com/tamdinhktmtk20/dashboards/project-mecanum")


# buttons events - LIGHTS
def buttonEvent__LIGHTS_LEFT_ON(client):
    client.publish("button_lights", globals.LEFT_ON)


def buttonEvent__LIGHTS_RIGHT_ON(client):
    client.publish("button_lights", globals.RIGHT_ON)


def buttonEvent__LIGHTS_LEFT_OFF(client):
    client.publish("button_lights", globals.LEFT_OFF)


def buttonEvent__LIGHTS_RIGHT_OFF(client):
    client.publish("button_lights", globals.RIGHT_OFF)


def buttonEvent__LIGHTS_ALL_ON(client):
    client.publish("button_lights", globals.ALL_ON)


def buttonEvent__LIGHTS_ALL_OFF(client):
    client.publish("button_lights", globals.ALL_OFF)


def buttonEvent__LIGHTS_PARKING_MODE_ON(client):
    client.publish("button_lights", globals.PARKING_MODE_ON)


def buttonEvent__LIGHTS_PARKING_MODE_OFF(client):
    client.publish("button_lights", globals.PARKING_MODE_OFF)


# buttons events - MOVEMENTS
def buttonEvent__MOVEMENTS_FORWARD(client):
    client.publish("button_movements", globals.FORWARD)


def buttonEvent__MOVEMENTS_BACKWARD(client):
    client.publish("button_movements", globals.BACKWARD)


def buttonEvent__MOVEMENTS_LEFT(client):
    client.publish("button_movements", globals.LEFT)


def buttonEvent__MOVEMENTS_RIGHT(client):
    client.publish("button_movements", globals.RIGHT)


def buttonEvent__MOVEMENTS_FORWARD_LEFT(client):
    client.publish("button_movements", globals.FORWARD_LEFT)


def buttonEvent__MOVEMENTS_FORWARD_RIGHT(client):
    client.publish("button_movements", globals.FORWARD_RIGHT)


def buttonEvent__MOVEMENTS_BACKWARD_LEFT(client):
    client.publish("button_movements", globals.BACKWARD_LEFT)


def buttonEvent__MOVEMENTS_BACKWARD_RIGHT(client):
    client.publish("button_movements", globals.BACKWARD_RIGHT)


def buttonEvent__MOVEMENTS_STOP(client):
    client.publish("button_movements", globals.STOP)


# buttons events - AI
def buttonEvent__AI_SWITCH_CAMERA():
    if globals.IP_camera == 0:
        globals.IP_camera = 'http://192.168.88.228:81/stream'
        tkinter.messagebox.showinfo(title="IP CAMERA", message="ESP32 CAMERA được lựa chọn thành công")
    else:
        globals.IP_camera = 0
        tkinter.messagebox.showinfo(title="IP CAMERA", message="LAPTOP CAMERA được lựa chọn thành công")


def buttonEvent__AI_FIRST_MODEL(client):
    counter = 40
    np.set_printoptions(suppress=True)
    model = load_model("keras_Model.h5", compile=False)
    class_names = ["Go Straight", "Turn Left", "Turn Right", "Parking"]
    camera = cv2.VideoCapture(globals.IP_camera)
    while True:
        # Grab the webcamera's image.
        ret, image = camera.read()

        # Resize the raw image into (224-height,224-width) pixels
        image = cv2.resize(image, (224, 224), interpolation=cv2.INTER_AREA)

        # Show the image in a window
        cv2.imshow("Webcam Image", image)

        # Make the image a numpy array and reshape it to the models input shape.
        image = np.asarray(image, dtype=np.float32).reshape(1, 224, 224, 3)

        # Normalize the image array
        image = (image / 127.5) - 1

        # Predicts the model
        prediction = model.predict(image)
        index = np.argmax(prediction)
        class_name = class_names[index]
        # confidence_score = prediction[0][index]

        # Print prediction and confidence score
        # print("Class:", class_name[2:], end="")
        # print("Confidence Score:", str(np.round(confidence_score * 100))[:-2], "%\n")
        if cv2.waitKey(1) & 0xFF == ord('1'):
            break
        else:
            counter = counter - 1
            if counter == 0:
                counter = 40
                client.publish("signs", class_name[:])
        time.sleep(0.1)
    camera.release()
    cv2.destroyAllWindows()


def buttonEvent__AI_OPEN_CAMERA_WINDOW():
    camera = cv2.VideoCapture(globals.IP_camera)
    while True:
        ret, image = camera.read()
        cv2.imshow('webcam', image)
        keyboard_input = cv2.waitKey(1)

        # 27 is the ASCII for the esc key on your keyboard.
        if keyboard_input == 27:
            break
    camera.release()
    cv2.destroyAllWindows()
