import customtkinter
from tkinter import *
from PIL import Image, ImageTk
import events
import globals


def animation(window, imageObject, gif_Label, frames, count):
    global showAnimation
    newImage = imageObject[count]
    gif_Label.configure(image=newImage)
    count += 1
    if count == frames:
        count = 0
    showAnimation = window.after(20, lambda: animation(window, imageObject, gif_Label, frames, count))


def looping(client):
    window = customtkinter.CTk()
    window.title(globals.WINDOW_NAME)
    window.geometry("1020x750")
    # window.iconbitmap("F:\PythonProject\Scheduler_Sample\Images\wheel.ico")
    window.config(background="#DDE9F5")
    window.resizable(False, True)

    # createLabel__TITLE
    label_Title = Label(window, text=globals.LABEL_TITLE,
                        font=("Comic Sans MS", 25, "bold"),
                        bg='#DDE9F5',
                        fg='#0D47A1')
    label_Title.pack()

    # createLabel__CONNECTIVITY
    label_Connectivity = Label(window, text=globals.LABEL_CONNECTIVITY,
                               font=("Comic Sans MS", 20, "bold"),
                               bg='#DDE9F5',
                               fg='green')
    label_Connectivity.place(x=0, y=70)

    # createButton__CONNECTIVITY_OHSTEM
    image_ohstem_icon = customtkinter.CTkImage(light_image=Image.open("Images/ohstem.jpg"), size=(25, 25))
    button_connectivity_ohstem = customtkinter.CTkButton(window,
                                                         image=image_ohstem_icon,
                                                         text=globals.BUTTON_CONNECTIVITY_OHSTEM,
                                                         font=('Sergoe UI', 22),
                                                         width=150,
                                                         height=40,
                                                         hover_color='dark blue',
                                                         text_color='white',
                                                         corner_radius=15,
                                                         compound='left',
                                                         fg_color='#89CFF0',
                                                         command=events.buttonEvent__CONNECTIVITY_APP_OHSTEM_HOMEPAGE)
    button_connectivity_ohstem.place(x=31, y=100)

    # createButton__CONNECTIVITY_BLUETOOTH
    image_bluetooth_icon = customtkinter.CTkImage(light_image=Image.open("Images/bluetooth.png"), size=(25, 25))
    button_connectivity_bluetooth = customtkinter.CTkButton(window,
                                                            image=image_bluetooth_icon,
                                                            text=globals.BUTTON_CONNECTIVITY_BLUETOOTH,
                                                            font=('Segoe UI', 22),
                                                            width=150,
                                                            height=40,
                                                            hover_color='dark blue',
                                                            text_color='white',
                                                            corner_radius=15,
                                                            compound='left',
                                                            fg_color='#89CFF0',
                                                            command=events.buttonEvent__CLICK)
    button_connectivity_bluetooth.place(x=390, y=100)

    # createButton__CONNECTIVITY_ADAFRUIT
    image_adafruit_icon = customtkinter.CTkImage(light_image=Image.open("Images/adafruit.png"), size=(25, 25))
    button_connectivity_adafruit = customtkinter.CTkButton(window,
                                                           image=image_adafruit_icon,
                                                           text=globals.BUTTON_CONNECTIVITY_ADAFRUIT,
                                                           font=('Segoe UI', 22),
                                                           width=150,
                                                           height=40,
                                                           hover_color='dark blue',
                                                           text_color='white',
                                                           corner_radius=15,
                                                           compound='left',
                                                           fg_color='#89CFF0',
                                                           command=events.buttonEvent__CONNECTIVITY_ADAFRUIT_HOMEPAGE)
    button_connectivity_adafruit.place(x=740, y=100)

    # createLabel__LIGHTS
    label_Lights = Label(window, text=globals.LABEL_LIGHTS,
                         font=("Comic Sans MS", 20, "bold"),
                         bg='#DDE9F5',
                         fg='green'
                         )
    label_Lights.place(x=0, y=220)

    # createButton__LIGHTS_LEFT_ON
    button_lights_left_on = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_LEFT_ON,
                                                    font=('Segoe UI', 22),
                                                    width=150,
                                                    height=40,
                                                    hover_color='#D4F4D4',
                                                    text_color='#3F51B5',
                                                    fg_color='#FFCF70',
                                                    corner_radius=15,
                                                    command=lambda: events.buttonEvent__LIGHTS_LEFT_ON(client))
    button_lights_left_on.place(x=31, y=220)

    # createButton__LIGHTS_RIGHT_ON
    button_lights_right_on = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_RIGHT_ON,
                                                     font=('Segoe UI', 22),
                                                     width=150,
                                                     height=40,
                                                     hover_color='#D4F4D4',
                                                     text_color='#3F51B5',
                                                     fg_color='#FFCF70',
                                                     corner_radius=15,
                                                     command=lambda: events.buttonEvent__LIGHTS_RIGHT_ON(client))
    button_lights_right_on.place(x=308.5, y=220)

    # createButton__LIGHTS_LEFT_OFF
    button_lights_left_off = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_LEFT_OFF,
                                                     font=('Segoe UI', 22),
                                                     width=150,
                                                     height=40,
                                                     hover_color='#D4F4D4',
                                                     text_color='#3F51B5',
                                                     fg_color='#FFCF70',
                                                     corner_radius=15,
                                                     command=lambda: events.buttonEvent__LIGHTS_LEFT_OFF(client))
    button_lights_left_off.place(x=562.5, y=220)

    # createButton__LIGHTS_RIGHT_OFF
    button_lights_right_off = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_RIGHT_OFF,
                                                      font=('Segoe UI', 22),
                                                      width=150,
                                                      height=40,
                                                      hover_color='#D4F4D4',
                                                      text_color='#3F51B5',
                                                      fg_color='#FFCF70',
                                                      corner_radius=15,
                                                      command=lambda: events.buttonEvent__LIGHTS_RIGHT_OFF(client))
    button_lights_right_off.place(x=823.5, y=220)

    # createButton__LIGHTS_ALL_ON
    button_lights_all_on = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_ALL_ON,
                                                   font=('Segoe UI', 22),
                                                   width=150,
                                                   height=40,
                                                   hover_color='#D4F4D4',
                                                   text_color='#3F51B5',
                                                   fg_color='#FFCF70',
                                                   corner_radius=15,
                                                   command=lambda: events.buttonEvent__LIGHTS_ALL_ON(client))
    button_lights_all_on.place(x=21.5, y=270)

    # createButton__LIGHTS_ALL_OFF
    button_lights_all_off = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_ALL_OFF,
                                                    font=('Segoe UI', 22),
                                                    width=150,
                                                    height=40,
                                                    hover_color='#D4F4D4',
                                                    text_color='#3F51B5',
                                                    fg_color='#FFCF70',
                                                    corner_radius=15,
                                                    command=lambda: events.buttonEvent__LIGHTS_ALL_OFF(client))
    button_lights_all_off.place(x=304, y=270)

    # createButton__LIGHTS_PARKING_MODE_ON
    button_lights_parking_mode_on = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_PARKING_MODE_ON,
                                                            font=('Segoe UI', 22),
                                                            width=150,
                                                            height=40,
                                                            hover_color='#D4F4D4',
                                                            text_color='#3F51B5',
                                                            fg_color='#FFCF70',
                                                            corner_radius=15,
                                                            command=lambda: events.buttonEvent__LIGHTS_PARKING_MODE_ON(
                                                                client))
    button_lights_parking_mode_on.place(x=553.5, y=270)

    # createButton__LIGHTS_PARKING_MODE_OFF
    button_lights_parking_mode_off = customtkinter.CTkButton(window, text=globals.BUTTON_LIGHTS_PARKING_MODE_OFF,
                                                             font=('Segoe UI', 22),
                                                             width=150,
                                                             height=40,
                                                             hover_color='#D4F4D4',
                                                             text_color='#3F51B5',
                                                             fg_color='#FFCF70',
                                                             corner_radius=15,
                                                             command=lambda: events.buttonEvent__LIGHTS_PARKING_MODE_OFF(
                                                                 client))
    button_lights_parking_mode_off.place(x=817, y=270)

    # createLabel__MOVEMENTS
    label_Movements = Label(window, text=globals.LABEL_MOVEMENTS,
                            font=("Comic Sans MS", 20, "bold"),
                            bg='#DDE9F5',
                            fg='green')
    label_Movements.place(x=0, y=435)

    gif_Label = Label(window, image="")
    gif_Label.place(x=100, y=530)

    gif2_Label = Label(window, image="")
    gif2_Label.place(x=970, y=530)

    gifImage = "Images/NC8m.gif"
    openImage = Image.open(gifImage)
    frames = openImage.n_frames
    imageObject = [PhotoImage(file=gifImage, format=f"gif -index {i}") for i in range(frames)]
    count = 0
    showAnimation = None

    animation(window, imageObject, gif_Label, frames, count)
    animation(window, imageObject, gif2_Label, frames, count)
    # createButton__MOVEMENTS_FORWARD
    image_forward = ImageTk.PhotoImage(Image.open("Images/forward_arrow.png").resize((50, 50)))
    button_movements_forward = Button(window,
                                      image=image_forward,
                                      bg='light green',
                                      command=lambda: events.buttonEvent__MOVEMENTS_FORWARD(client))
    button_movements_forward.place(x=615, y=540)

    # createButton__MOVEMENTS_BACKWARD
    image_backward = ImageTk.PhotoImage(Image.open("Images/backward_arrow.png").resize((50, 50)))
    button_movements_backward = Button(window,
                                       image=image_backward,
                                       bg='light green',
                                       command=lambda: events.buttonEvent__MOVEMENTS_BACKWARD(client))
    button_movements_backward.place(x=615, y=660)

    # createButton__MOVEMENTS_RIGHT
    image_right = ImageTk.PhotoImage(Image.open("Images/right_arrow.png").resize((50, 50)))
    button_movements_right = Button(window,
                                    image=image_right,
                                    bg='light green',
                                    command=lambda: events.buttonEvent__MOVEMENTS_RIGHT(client))
    button_movements_right.place(x=675, y=600)

    # createButton__MOVEMENTS_LEFT
    image_left = ImageTk.PhotoImage(Image.open("Images/left_arrow.png").resize((50, 50)))
    button_movements_left = Button(window,
                                   image=image_left,
                                   bg='light green',
                                   command=lambda: events.buttonEvent__MOVEMENTS_LEFT(client))
    button_movements_left.place(x=555, y=600)

    # createButton__MOVEMENTS_FORWARD_LEFT
    image_forward_left = ImageTk.PhotoImage(Image.open("Images/forward_left_arrow.png").resize((50, 50)))
    button_movements_forward_left = Button(window,
                                           image=image_forward_left,
                                           bg='light green',
                                           command=lambda: events.buttonEvent__MOVEMENTS_FORWARD_LEFT(client))
    button_movements_forward_left.place(x=555, y=540)

    # createButton__MOVEMENTS_FORWARD_RIGHT
    image_forward_right = ImageTk.PhotoImage(Image.open("Images/forward_right_arrow.png").resize((50, 50)))
    button_movements_forward_right = Button(window,
                                            image=image_forward_right,
                                            bg='light green',
                                            command=lambda: events.buttonEvent__MOVEMENTS_FORWARD_RIGHT(client))
    button_movements_forward_right.place(x=675, y=540)

    # createButton__MOVEMENTS_BACKWARD_LEFT
    image_backward_left = ImageTk.PhotoImage(Image.open("Images/backward_left_arrow.png").resize((50, 50)))
    button_movements_backward_left = Button(window,
                                            image=image_backward_left,
                                            bg='light green',
                                            command=lambda: events.buttonEvent__MOVEMENTS_BACKWARD_LEFT(client))
    button_movements_backward_left.place(x=555, y=660)

    # createButton__MOVEMENTS_BACKWARD_RIGHT
    image_backward_right = ImageTk.PhotoImage(Image.open("Images/backward_right_arrow.png").resize((50, 50)))
    button_movements_backward_right = Button(window,
                                             image=image_backward_right,
                                             bg='light green',
                                             command=lambda: events.buttonEvent__MOVEMENTS_BACKWARD_RIGHT(client))
    button_movements_backward_right.place(x=675, y=660)

    # createButton__MOVEMENTS_STOP
    image_stop = ImageTk.PhotoImage(Image.open("Images/stop.png").resize((50, 50)))
    button_movements_stop = Button(window,
                                   image=image_stop,
                                   bg='light green',
                                   command=lambda: events.buttonEvent__MOVEMENTS_STOP(client))
    button_movements_stop.place(x=615, y=600)

    # createLabel__AI
    label_Ai = Label(window, text=globals.LABEL_AI,
                     font=("Comic Sans MS", 20, "bold"),
                     bg='#DDE9F5',
                     fg='green')
    label_Ai.place(x=0, y=780)

    # createButton__AI_SIGNS_RECOGNITION
    button_ai_signs_recognition = customtkinter.CTkButton(window,
                                                          text=globals.BUTTON_AI_SIGNS_RECOGNITION,
                                                          font=('Segoe UI', 22),
                                                          width=150,
                                                          height=40,
                                                          hover_color='#228B22',
                                                          text_color='#D4F4D4',
                                                          fg_color='#DD7788',
                                                          corner_radius=15,
                                                          command=lambda: events.buttonEvent__AI_FIRST_MODEL(client))
    button_ai_signs_recognition.place(x=20, y=670)

    # createButton__AI_VOICE_RECOGNITION
    button_ai_voice_recognition = customtkinter.CTkButton(window,
                                                          text=globals.BUTTON_AI_VOICE_RECOGNITION,
                                                          font=('Segoe UI', 22),
                                                          width=150,
                                                          height=40,
                                                          hover_color='#228B22',
                                                          text_color='#D4F4D4',
                                                          fg_color='#DD7788',
                                                          corner_radius=15,
                                                          command=events.buttonEvent__CLICK)
    button_ai_voice_recognition.place(x=270, y=670)

    # createButton__AI_OPEN_COMPUTER_CAMERA
    button_ai_open_computer_camera = customtkinter.CTkButton(window,
                                                             text=globals.BUTTON_AI_OPEN_CAMERA,
                                                             font=('Segoe UI', 22),
                                                             width=150,
                                                             height=40,
                                                             hover_color='#228B22',
                                                             text_color='#D4F4D4',
                                                             fg_color='#DD7788',
                                                             corner_radius=15,
                                                             command=events.buttonEvent__AI_OPEN_CAMERA_WINDOW)
    button_ai_open_computer_camera.place(x=530, y=670)

    # createButton__AI_SWITCH_CAMERA
    button_ai_switch_camera = customtkinter.CTkButton(window,
                                                      text=globals.BUTTON_AI_SWITCH_CAMERA,
                                                      font=('Segoe UI', 22),
                                                      width=150,
                                                      height=40,
                                                      hover_color='#228B22',
                                                      text_color='#D4F4D4',
                                                      fg_color='#DD7788',
                                                      corner_radius=15,
                                                      command=events.buttonEvent__AI_SWITCH_CAMERA)
    button_ai_switch_camera.place(x=780, y=670)

    window.mainloop()
